# Prompt 01: Exterior Massing — Isometric Shell Render

## When to Use
Generating a clean exterior 3D view from a specific angle. Start here for any new rendering session.

## Template

```
Generate a high-precision architectural massing render of the Calhoun Carriage House.

VIEWPOINT: [substitute from options below]
STYLE: Clean white-clay architectural model. No textures, no landscaping, no color. White/light gray surfaces with subtle shadows to reveal form. Crisp structural lines. Studio lighting on neutral gray background.

BEFORE YOU GENERATE — THINK STEP BY STEP:

Step 1: Identify which walls are visible from this viewpoint.
Step 2: For each visible wall, list EVERY element from the Cardinal Wall Axioms. Do not add anything not listed. Do not omit anything listed.
Step 3: Confirm staircase placement — it runs along the SOUTH wall, ascending west-to-east. Is it visible from this angle? If yes, render it. If no, do not invent one.
Step 4: Confirm deck geometry — L-shaped, wrapping SOUTH and WEST only. Is it visible? Render only what's visible.
Step 5: Confirm the south wall ground level is SOLID. No openings. No pass-throughs. Enclosed structure under the stairs.
Step 6: Confirm deck platform at the TOP of the staircase — this is the arrival surface at second-floor level.
Step 7: Confirm roof — 3:12 LOW-SLOPE gable, ridge E-W, gable triangles on N and S only.

Now generate the rendering. After generating, run the VALIDATION CHECKLIST from your system prompt before presenting.

OUTPUT: Single isometric architectural rendering.
```

## Viewpoint Options

| ID | Viewpoint | Primary Wall | Secondary Wall | Key Features Visible |
|----|-----------|-------------|----------------|---------------------|
| SE | Southeast Isometric 45° | East (3 garage doors) | South (staircase) | Garage frontage, staircase ascending L-to-R, deck at top |
| SW | Southwest Isometric 45° | South (staircase) | West (door 100A, deck) | Staircase ascending R-to-L, deck L-junction at SW corner |
| NE | Northeast Isometric 45° | East (3 garage doors) | North (door 100E) | Garage frontage, entry door, NO staircase visible |
| NW | Northwest Isometric 45° | North (door 100E) | West (deck, door 100A) | Entry door, deck wrapping from south, NO staircase |

## Pro Tip
Start with **SE Isometric** — it's the highest-information view (shows the most constrained elements: 3 garage doors + staircase + deck). If this view passes validation, the model has internalized the axioms correctly.
