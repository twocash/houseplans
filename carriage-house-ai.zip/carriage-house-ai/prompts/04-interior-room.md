# Prompt 04: Interior Room Render — Perspective Views

## When to Use
Generating an interior perspective of a specific room. Use the pre-filled variants below or customize.

## Base Template

```
Generate an interior perspective rendering of {ROOM_NAME} (Room {NUMBER}) in the Calhoun Carriage House second floor.

CAMERA: Standing at {ENTRY_POINT}, looking {DIRECTION}.
CEILING: {CEILING_TYPE}
FLOOR: {FLOOR_TYPE}
WALLS: Painted GYP BD

ROOM CONTENTS:
{ELEMENT_LIST}

ADJACENT SPACES VISIBLE:
{ADJACENCY_LIST}

WINDOWS: {WINDOW_LIST}
LIGHTING: {LIGHT_SOURCES}

STYLE: Warm residential interior, natural materials, clean modern aesthetic. Realistic lighting.

CRITICAL CEILING RULE: ONLY Room 200 (Living Room) has a vaulted ceiling. Every other room has an 8' flat GYP BD ceiling. If this is NOT Room 200, the ceiling MUST be flat.
```

## Pre-Filled Variants

### Living Room (200) — The Hero Space
```
Room: Living Room (200)
Camera: Standing at corridor entry on north side, looking SOUTH
Ceiling: VAULTED — T&G wood planks at 3:12 pitch, (2) wood-clad collar ties, faux beam at ridge with LED strips
Floor: Wood
Contents: Electric fireplace with stone/wood accent wall on south-facing wall, +72" TV mounted on north partition (behind camera), sofa facing north, coffee table centered, accent chairs flanking sofa
Adjacent: Open sightline EAST to Kitchenette (201), corridor to bedrooms/bathrooms behind camera (north)
Windows: South wall windows, east wall windows
Lighting: Dimmable LED strips on faux beams, natural light from S/E windows
Ceiling height: ~10'-6" at ridge, ~9'-6" at collar ties
```

### Kitchenette (201)
```
Room: Kitchenette (201)
Camera: Standing at living room boundary, looking SOUTHEAST into kitchen
Ceiling: 8' FLAT (NOT vaulted)
Floor: Wood
Contents: Counter run on south wall (30"-15"-30" base cabinets with sink), 30" range at SE corner, exhaust hood above range, upper outlets at +48" and +72"
Adjacent: Open to Living Room (200) behind/beside camera — no wall
Windows: East wall window(s)
Lighting: Ceiling fixture, under-cabinet task light, natural light from east
```

### Utility/Entry (208)
```
Room: Utility/Entry (208)
Camera: Just inside door 200A from deck, looking EAST into corridor
Ceiling: 8' FLAT
Floor: Wood
Contents: Storage bench, coat hooks, shoe shelf, wall-mounted tankless water heater, furnace on stand
Adjacent: Corridor east toward living area, north toward bathrooms/bedrooms. Deck visible through door 200A behind camera.
Windows: Light from deck door
Lighting: Ceiling fixture
```

### Bedroom 206 (NE)
```
Room: Bedroom 206
Camera: Standing at door, looking NORTHEAST toward corner
Ceiling: 8' FLAT GYP
Floor: Wood
Contents: Queen bed, nightstands, dresser, closet door (207)
Adjacent: Hallway behind camera
Windows: North wall W1, East wall W1
Lighting: Ceiling fixture, natural light from two exposures
```
