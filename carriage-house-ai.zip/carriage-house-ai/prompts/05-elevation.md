# Prompt 05: Flat Elevation — Single Wall Face

## When to Use
Generating an orthographic (flat, no perspective) elevation of one specific wall. Useful for validating element placement and proportions against the construction drawings.

## Template

```
Generate a flat architectural elevation of the {DIRECTION} WALL of the Calhoun Carriage House.

VIEW: Straight-on orthographic. No perspective, no angle. Viewer standing directly in front of this wall face.

WALL CONTENTS: Refer to the Cardinal Wall Axiom for the {DIRECTION} WALL in your system prompt. Render EVERY element listed. Render NOTHING not listed.

STYLE: Clean architectural elevation drawing — white/light surfaces, dark outlines, labeled elements. Ground line at bottom, ridge line at top. Dimension lines where possible.

PROPORTIONS:
- Ground floor height: ~9' (slab to second-floor structure)
- Second floor to ridge: ~13' (with 3:12 pitch)
- Total height: ~24' grade to ridge
- Wall width: {30' for E/W walls, 34'-8" for N/S walls}
- Garage doors: 9' × 9' each
- Person doors: 3' × 7'
- Windows: per schedule (W1: 3'×5'-4", W2: 6'×5'-4", W3: 2'×4', W4: 2'-6"×3')

Before generating, list every element this wall contains per the axiom. Then render exactly that list.
```
