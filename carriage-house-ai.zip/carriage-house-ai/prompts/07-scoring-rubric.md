# Prompt 07: Self-Grading Rubric — Render Quality Assessment

## When to Use
After any render generation. Forces the model to score its own output on a structured rubric before presenting. Can be appended to any other prompt, or used standalone on an existing image.

## Why This Exists
LLMs generate in a single forward pass and don't "look at" their own output. A scoring rubric forces a second reasoning pass that acts as quality control. The model must articulate what it sees in its own render, which surfaces errors it would otherwise miss.

## Template

```
Before presenting this rendering, score it on the following rubric. Be BRUTALLY HONEST. A score below 7/10 on any category means REGENERATE — do not present the image.

STRUCTURAL ACCURACY (10 points)
- 10: Every element matches the Cardinal Wall Axioms exactly. Correct count of doors, windows, openings on every visible wall. No phantom elements.
- 7-9: Minor proportional errors but all elements present and on correct walls.
- 4-6: One or more elements on wrong wall, or missing/extra elements.
- 0-3: Fundamental axiom violations (garage doors on wrong wall, missing staircase, etc.)

SCORE: ___/10
EVIDENCE: [List each element you can identify and which wall it's on. Count garage doors. Count windows.]

SPATIAL GEOMETRY (10 points)
- 10: Roof pitch reads as low-slope 3:12. Gable triangles only on N/S. Building proportions match 30'×34'-8" footprint. Heights proportionally correct.
- 7-9: Pitch slightly off or proportions slightly stretched, but fundamentally correct geometry.
- 4-6: Wrong roof type, or proportions significantly distorted.
- 0-3: Impossible geometry — floating elements, intersecting planes, wrong roof form entirely.

SCORE: ___/10
EVIDENCE: [Describe roof form, pitch impression, gable end locations, overall proportion feel.]

STAIRCASE FIDELITY (10 points)
- 10: Staircase clearly on south wall, ascending west (ground) to east (deck), solid structure beneath, deck platform visible at top.
- 7-9: Staircase in correct position with minor rendering artifacts.
- 4-6: Staircase present but wrong direction, wrong wall, or missing deck landing.
- 0-3: No staircase, or staircase in completely wrong location.
- N/A: Staircase not visible from this viewpoint (NE, NW angles).

SCORE: ___/10
EVIDENCE: [Describe staircase position, direction of ascent, what's visible at top and bottom.]

DECK ACCURACY (10 points)
- 10: L-shaped deck wrapping south and west sides only. Visible at second-floor level. Supported by posts. Railing present. NOT on north or east walls.
- 7-9: Deck in correct position with minor railing or post issues.
- 4-6: Deck present but extending to wrong walls or missing one leg of the L.
- 0-3: No deck, or deck on wrong sides entirely.

SCORE: ___/10
EVIDENCE: [Describe which sides show the deck, whether railing is visible, post support.]

SOUTH WALL SOLIDITY (10 points)
- 10: South wall ground level is clearly solid — continuous siding, no openings, no pass-throughs, no bays. Enclosed structure under stairs.
- 7-9: Mostly solid with minor ambiguity in under-stair area.
- 4-6: Visible opening or pass-through at ground level on south wall.
- 0-3: Clear drive-through or open bay on south wall.
- N/A: South wall not visible from this viewpoint.

SCORE: ___/10
EVIDENCE: [Describe what you see at ground level on the south wall.]

OVERALL RENDER QUALITY (10 points)
- 10: Clean, professional architectural model quality. Consistent lighting, sharp edges, no artifacts, readable at presentation scale.
- 7-9: Good quality with minor rendering artifacts.
- 4-6: Noticeable quality issues but structurally readable.
- 0-3: Poor quality — muddy, distorted, or unreadable.

SCORE: ___/10

TOTAL: ___/60
PASS THRESHOLD: 42/60 (70%) with NO individual category below 7/10.
VERDICT: [PASS — Present] or [FAIL — Regenerate with corrections listed below]

If FAIL, list specific corrections needed:
1. ...
2. ...
3. ...
```

## Usage Notes

Append this rubric to the end of any generation prompt with the instruction: "After generating, score your output using the attached rubric before presenting."

Alternatively, send the rubric as a follow-up message after receiving a render, along with the image, to get the model to audit its own work.

The key insight: models that score their own output catch ~40% more errors than models that simply generate and present. The rubric forces the kind of structured attention that counteracts single-pass hallucination.
