# Prompt 03: Top-Down Plan View — Second Floor Layout

## When to Use
Generating a birds-eye view of the second floor interior. Tests whether the model has internalized the spatial map.

## Template

```
Generate a top-down architectural plan view of the Calhoun Carriage House second floor.

ORIENTATION: North = top of image.
STYLE: Clean architectural plan — white walls as solid dark lines, labeled rooms, furniture shown as plan-view outlines. Light wood tones for living areas, light tile tones for wet rooms.

BEFORE GENERATING — CONFIRM ROOM POSITIONS:

I will now place each room in its correct quadrant per the system prompt:

NORTHWEST: Shower (209) against north wall → Utility/Entry (208) against west wall
NORTH-CENTER: Bathroom (204) → Toilet (205)
NORTHEAST: Bedroom 206 + Closet 207 — against north and east walls
EAST-CENTER: Bedroom 202 + Closet 203 — against east wall
SOUTH-CENTER/SOUTHWEST: Living Room (200) — THE LARGEST ROOM. Occupies most of the southern half. Vaulted ceiling zone.
SOUTHEAST CORNER: Kitchenette (201) — open to living room (NO wall between them). Range at SE corner.

DECK: L-shaped (Room 212) wrapping SOUTH and WEST edges. Staircase arrives at SW corner.

CRITICAL SPATIAL RULES:
- Living room (200) is LARGER than any other room — it dominates the floor plan
- Kitchenette (201) is OPEN to the living room — no wall separation
- The +72" TV is on the NORTH-facing interior partition wall in the living room
- The 30" range is at the SE corner of the kitchenette against the south wall
- Bedrooms are ONLY along the north and east exterior walls
- The interior corridor connects utility/entry (NW) to the bedroom zone (NE/E)
- The corridor separates the living room from the bedroom/bathroom zones

FURNITURE TO SHOW:
- Living Room: Sofa facing north wall, coffee table, 2 accent chairs, TV on north partition, electric fireplace on accent wall
- Kitchenette: Counter run with sink along south wall, range at SE corner, base cabinets
- Bedrooms: Queen bed, nightstands, dresser
- Bathroom: Vanity, sink
- Shower: Shower enclosure
- Utility/Entry: Storage bench, shoe rack

Label every room with its number and name. Show door swings. Show the deck with railing hatching.
```
