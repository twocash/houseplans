# Prompt 02: Axiom Audit — Post-Render Validation

## When to Use
After EVERY render generation. Non-negotiable. Send this prompt along with the generated image to force a structured compliance check.

## Template

```
Analyze the attached rendering of the Calhoun Carriage House. Audit every visible element against the Cardinal Wall Axioms in your system prompt.

INSTRUCTIONS: For each visible wall, count and identify every architectural element. Compare your count against the axiom specification. Report discrepancies.

EAST WALL (if visible):
- Count overhead garage doors: ___ (required: exactly 3)
- Count second-floor windows: ___ (required: 4)
- Deck or staircase present? (required: NO — neither should appear on east wall)

WEST WALL (if visible):
- Count overhead doors: ___ (required: exactly 1, positioned toward south end)
- Deck at second floor? (required: YES)
- Entry doors 200A/200B at second floor? (required: YES)
- Staircase on this wall? (required: NO — staircase is on south wall)

NORTH WALL (if visible):
- Entry door 100E at NW corner? (required: YES)
- Count second-floor windows: ___ (required: 3)
- Gable triangle at peak? (required: YES)
- Garage doors? (required: ZERO)

SOUTH WALL (if visible):
- Staircase present? (required: YES)
- Staircase direction? (required: ascending WEST to EAST)
- Deck platform at TOP of staircase? (required: YES)
- Ground level openings/pass-throughs? (required: NONE — solid wall)
- Gable triangle at peak? (required: YES)
- Garage doors? (required: ZERO)

ROOF:
- Pitch: ___ (required: 3:12 low-slope)
- Form: ___ (required: gable)
- Ridge direction: ___ (required: east-west)
- Gable triangles on: ___ (required: north and south walls ONLY)

DECK:
- Present on which walls? ___ (required: south and west ONLY)
- L-shape visible? (required: YES if both south and west walls visible)
- Railing with panels? (required: YES)
- Posts from ground? (required: YES)

VERDICT: [ALL PASS] or [FAILURES DETECTED — list corrections]
```
