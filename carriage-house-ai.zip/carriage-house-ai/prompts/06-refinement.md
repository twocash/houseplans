# Prompt 06: Multi-Pass Refinement — Error Correction

## When to Use
When an axiom audit (Prompt 02) or scoring rubric (Prompt 07) identifies specific errors. This prompt tells the model exactly what to fix.

## Template

```
The previous rendering contains the following axiom violations:

ERRORS:
1. {describe error — what's wrong and where}
2. {describe error}
3. {describe error}

REQUIRED CORRECTIONS:
1. {what the correct rendering should show}
2. {what the correct rendering should show}
3. {what the correct rendering should show}

Regenerate the rendering with ALL corrections applied. Maintain the same viewpoint, style, and lighting. Change ONLY the identified errors.

BEFORE OUTPUTTING — run the complete VALIDATION CHECKLIST (both Exterior and Interior sections). Score yourself on the rubric from Prompt 07. Present only if total score ≥ 42/60 with no category below 7/10.
```

## Tips for Effective Refinement

1. **Be specific about location.** "The south wall shows an opening at ground level beneath the staircase" is better than "there's an error on the south wall."

2. **Name the hallucination.** Reference the Known Hallucinations catalog (e.g., "This is H-001: South Wall Pass-Through"). The model benefits from seeing the pattern labeled.

3. **State both what's WRONG and what's RIGHT.** "The opening should be solid lap siding — the area under the staircase is enclosed structure, not a passage."

4. **Limit to 3 corrections per pass.** More than 3 and the model tends to fix some while breaking others. Multiple small passes > one large correction.

5. **Re-audit after every refinement.** Each correction can introduce new errors. Always run Prompt 02 on the refined output.
