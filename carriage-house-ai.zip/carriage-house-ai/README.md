# Carriage House AI — Precision Architectural Rendering System

A constraint-driven prompt architecture for generating structurally accurate 3D renderings using Google AI Studio (Gemini). Built to solve the core problem of LLM image generation: **spatial hallucination**.

## The Problem

Generative AI models produce visually appealing architectural renders that are structurally wrong. They invent doors, duplicate walls, mirror staircases, create impossible pass-throughs, and ignore building geometry. For a real construction project with permitted plans, these errors make the outputs useless.

## The Solution

A layered prompt system that treats architectural facts as **axioms** — non-negotiable constraints the model must verify before every output. The system uses:

1. **Cardinal Wall Axioms** — Every wall face is defined by its compass direction with an exhaustive element inventory. The model cannot guess what goes where.
2. **Spatial Maps** — Room-by-room quadrant definitions with adjacency rules, so interior layouts are positionally locked.
3. **Negative Constraint Lists** — Explicit "NEVER" rules targeting the specific hallucinations LLMs produce (pass-throughs, mirrored stairs, phantom doors).
4. **Self-Validation Checklists** — Forced pre-output verification the model must run before presenting any render.
5. **Agent Prompts** — Task-specific instructions that invoke the axiom system for different rendering operations.

## Architecture

```
system-prompt.md          ← The "constitution" — loaded as system context for every session
prompts/
  01-exterior-massing.md  ← Isometric shell renders (white clay model)
  02-axiom-audit.md       ← Post-render validation against wall axioms
  03-plan-view.md         ← Top-down second floor layout
  04-interior-room.md     ← Interior perspective renders per room
  05-elevation.md         ← Flat orthographic wall elevations
  06-refinement.md        ← Error correction / multi-pass iteration
  07-scoring-rubric.md    ← Self-grading rubric for render quality
docs/
  building-specs.md       ← Source of truth: dimensions, schedules, materials
  known-hallucinations.md ← Catalog of failure modes and their fixes
```

## Usage in Google AI Studio

1. **Load `system-prompt.md` as the System Instruction** for your Gemini session
2. **Upload construction documents** (floor plans, elevations, sections) as context
3. **Send an Agent Prompt** from the `prompts/` directory as your user message
4. **Run Prompt 02 (Axiom Audit)** on every output to catch errors
5. **Use Prompt 06 (Refinement)** to iterate on any failures

## Building

**Calhoun Carriage House** — 4317 N Park Ave, Indianapolis, IN 46205
- 2-story detached accessory structure: 3-car garage + apartment
- 30' × 34'-8" footprint, ~24' total height
- 3:12 pitch gable roof, ridge running E-W
- Construction documents by Medley Creations, Inc. (permitted 2025)

## Why This Works

The prompt system exploits three properties of LLM behavior:

1. **Axioms override priors.** LLMs have strong priors about what buildings "usually" look like. Cardinal wall axioms override these priors with specific facts, reducing hallucination.

2. **Negative constraints are stickier than positive ones.** "NEVER show a pass-through on the south wall" is more effective than "the south wall is solid" because it names the exact failure mode.

3. **Self-validation forces attention.** A checklist the model must run before outputting creates a second pass of reasoning that catches errors the generation pass missed.

## Status

- [x] Exterior massing: Validated at Pass 7.0 — correct wall assignments, staircase direction, deck geometry
- [ ] Interior plan views: Spatial map defined, testing in progress
- [ ] Interior room renders: Constraint definitions complete, testing needed
- [ ] Furniture layout: Template ready, not yet tested
- [ ] Multi-angle consistency: Need to verify same building across all 4 isometric views
