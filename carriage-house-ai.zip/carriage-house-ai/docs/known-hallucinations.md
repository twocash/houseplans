# Known Hallucination Catalog

Documented failure modes from iterative testing with Gemini image generation on this building. Each entry describes the hallucination, why it happens, and which constraint in the system prompt addresses it.

## Severity Levels
- 🔴 **Critical** — Fundamentally wrong structure. Would mislead anyone viewing the render.
- 🟡 **Major** — Wrong element placement or count. Noticeable to anyone comparing to plans.
- 🟢 **Minor** — Proportional or detail error. Only visible to someone who knows the plans well.

---

## H-001: South Wall Pass-Through 🔴
**What happens:** The model renders an open bay, walkway, or drive-through opening at ground level on the south wall, typically beneath the staircase.

**Why it happens:** The model sees "staircase" and infers an open area beneath the stairs, similar to a parking garage ramp. It applies a prior about under-stair spaces being open rather than reading the constraint that this area is enclosed.

**Fix applied:** South Wall Axiom explicitly states "SOLID ENCLOSED WALL" at ground level. NEVER list includes "NEVER show pass-through on south wall" and "NEVER render under-stair area as open walkway." Validation checklist includes south wall solidity check.

**Status:** ✅ Fixed at Pass 7.0

---

## H-002: Staircase on Wrong Wall 🔴
**What happens:** Staircase appears on the west wall instead of the south wall, or appears as an interior staircase.

**Why it happens:** The model associates "entry to second floor" with the west wall (which has the deck entry doors) and places the staircase there as the most "logical" access point.

**Fix applied:** South Wall Axiom defines the staircase explicitly. West Wall Axiom includes a CRITICAL note that the west wall shows the deck but NOT the staircase itself. NEVER list targets this: "NEVER place the staircase on the WEST wall."

**Status:** ✅ Fixed at Pass 5.0

---

## H-003: Staircase Ascending Wrong Direction 🔴
**What happens:** Staircase ascends from east to west instead of west to east.

**Why it happens:** The model may mirror the staircase based on the viewpoint angle, or default to a "left-to-right" rendering convention regardless of the actual direction.

**Fix applied:** NEVER list: "NEVER show the staircase ascending from east to west." South Wall Axiom: "ascends from WEST (ground) to EAST (deck)." Viewpoint definitions specify L-to-R or R-to-L based on viewing angle.

**Status:** ✅ Fixed at Pass 6.0

---

## H-004: Garage Doors on North Wall 🔴
**What happens:** One or more overhead garage doors appear on the north wall.

**Why it happens:** The model spreads garage doors across multiple walls to "balance" the facade, rather than concentrating all three on the east wall. This is a strong visual prior — buildings "should" have symmetrical openings.

**Fix applied:** North Wall Axiom: "ZERO garage doors." East Wall Axiom: "This is the ONLY wall with three garage doors." NEVER list: "NEVER place garage doors on the NORTH wall."

**Status:** ✅ Fixed at Pass 3.0

---

## H-005: Drive-Through Garage Configuration 🔴
**What happens:** The model aligns the east wall garage doors with the west wall shop door (100A) to create a drive-through garage, as if vehicles could enter one side and exit the other.

**Why it happens:** The model sees overhead doors on both the east and west walls and infers they're aligned for through-traffic — a common commercial garage pattern.

**Fix applied:** NEVER list: "NEVER show a drive-through garage configuration." West Wall Axiom notes door 100A is "positioned toward the SOUTH end of this wall" and "not aligned with the three east doors."

**Status:** ✅ Fixed at Pass 4.0

---

## H-006: Missing Deck at Top of Staircase 🟡
**What happens:** The staircase terminates at the building wall without a visible deck platform. The stairs appear to end at a door or just disappear into the wall face.

**Why it happens:** The model renders the staircase as a simple ramp-to-door, without understanding that the stairs land on an exterior deck platform that then provides access to the second-floor doors.

**Fix applied:** South Wall Axiom: "At the TOP of the staircase, a DECK LANDING connects to the L-shaped deck platform." NEVER list: "NEVER omit the deck platform at the TOP of the staircase." Deck Geometry section defines the L-corner at SW as the arrival point.

**Status:** ✅ Fixed at Pass 7.0

---

## H-007: Steep Roof Pitch 🟡
**What happens:** The roof renders as a steep A-frame (12:12 or similar) instead of the specified low-slope 3:12 gable.

**Why it happens:** Models have a strong visual prior for "gable roof = steep." A 3:12 pitch is unusually shallow and doesn't match the prototypical gable image in training data.

**Fix applied:** Building Identity section specifies "3:12 pitch." Geometry rules: "this is a LOW-SLOPE gable, not a steep A-frame." Validation checklist includes pitch check. The massing filter description reinforces "12:3 pitch gable roof logic."

**Status:** ✅ Fixed at Pass 5.0 (with "high-precision technical massing" style filter)

---

## H-008: Deck on North or East Walls 🟡
**What happens:** The deck wraps around to the north or east walls, or appears as a full perimeter balcony.

**Why it happens:** The model generalizes "second-floor deck" into a wrap-around balcony. Perimeter decks are a common residential pattern.

**Fix applied:** Deck Geometry section: "The deck does NOT exist on the NORTH or EAST walls." NEVER list: "NEVER show the deck on the NORTH or EAST walls." Validation checklist includes deck-side verification.

**Status:** ✅ Fixed at Pass 6.0

---

## H-009: Flat or Hip Roof 🟡
**What happens:** The roof renders as flat, hipped, or shed-style instead of gable.

**Why it happens:** Some rendering modes default to flat roofs for commercial/garage buildings, or hip roofs for residential. The model may also struggle with the low 3:12 pitch and flatten it entirely.

**Fix applied:** NEVER list: "NEVER show a flat roof, hip roof, or shed roof." Geometry rules specify "ALWAYS a 3:12 gable with E-W ridge." Gable triangles defined on N and S walls.

**Status:** ✅ Fixed at Pass 2.0

---

## H-010: Extra or Missing Garage Doors 🟡
**What happens:** The model renders 2 or 4 garage doors on the east wall, or adds garage doors to other walls beyond what's specified.

**Why it happens:** The model either loses count or applies a symmetry prior (2 or 4 doors look more "balanced" than 3).

**Fix applied:** East Wall Axiom: "Three 9'-0" × 9'-0" overhead garage doors" with individual labels (100B, 100C, 100D). NEVER list: "NEVER show more than 3 overhead garage doors total." Validation checklist: "Exactly 3 overhead garage doors."

**Status:** ✅ Fixed at Pass 4.0

---

## H-011: Recessed SE Bay as Ground-Level Opening 🟢
**What happens:** The SE corner where the deck overhangs the garage structure below is rendered as an open ground-level bay or recessed garage entry.

**Why it happens:** The shadow/soffit created by the deck overhang looks like a recessed opening from certain angles. The model interprets this depth as a bay.

**Fix applied:** Rendering Rules: "Recessed bay at SE corner where deck overhangs garage below (overhead shadow, NOT an opening)." Deck Geometry section: "this is an overhead condition (soffit/shadow), NOT a ground-level opening."

**Status:** ⚠️ Intermittent — appears in some angles, not others

---

## H-012: Interior Room Misplacement (Untested) 🟡
**What happens:** When rendering interior plan views, rooms appear in wrong quadrants (e.g., kitchen in the NW, bedrooms in the south).

**Why it happens:** Without explicit spatial anchoring, the model will place rooms based on generic residential floor plan conventions rather than the specific layout.

**Fix applied:** Second Floor Spatial Map with quadrant definitions, wall adjacency rules, and interior circulation path. Validation checklist includes interior position checks.

**Status:** 🔲 Not yet tested — constraint defined but awaiting render verification

---

## OBSERVATION LOG

**Pass 1-2:** Fundamental roof errors, garage doors everywhere, no staircase
**Pass 3-4:** Roof corrected, garage doors locked to east, staircase appeared but on wrong wall or wrong direction
**Pass 5-6:** Staircase corrected, but south wall pass-through appeared, deck incomplete
**Pass 7.0:** First clean exterior pass — all critical axioms verified, staircase correct, south wall solid, deck platform visible

**Pattern:** Each fix required BOTH a positive constraint (what IS there) AND a negative constraint (what is NEVER there). Positive-only constraints reduced but didn't eliminate hallucination. The NEVER list was the decisive addition.
